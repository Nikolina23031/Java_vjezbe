package posleKolkvijuma;

public class Knjiga {
	private String naziv;
	private String autor;
	private int idKnjige;
	private boolean dostupna;

	public Knjiga(String naziv, String autor, int idKnjige, boolean dostupna) {
		super();
		this.naziv = naziv;
		this.autor = autor;
		this.idKnjige = idKnjige;
		this.dostupna = dostupna;
	}

	public String prikaziKnjigu() {
		return "Knjiga [naziv=" + naziv + ", autor=" + autor + ", idKnjige=" + idKnjige + ", dostupna=" + dostupna
				+ "]";
	}
}
