package posleKolkvijuma;

public class PremijumClanstvo extends StandarnoClanstvo {
	private static final double POPUST = 0.15;

	public PremijumClanstvo(String imePrezime, Biblioteka biblioteka) {
		super(imePrezime, biblioteka);
	}

	@Override
	public int getMaksPozajmljenihKnjiga() {
		return 9;
	}

	@Override
	public double izracunajGodisnjuNaknadu() {
		return super.izracunajGodisnjuNaknadu() * (1 - POPUST);
	}
}
