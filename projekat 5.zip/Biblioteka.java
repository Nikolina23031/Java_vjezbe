package posleKolkvijuma;

import java.util.ArrayList;

class Biblioteka {
	private String ime;
	private int id;
	private ArrayList<String> dostupneKnjige;

	public Biblioteka(String ime, int id, ArrayList<String> dostupneKnjige) {
		this.ime = ime;
		this.id = id;
		this.dostupneKnjige = new ArrayList<>(dostupneKnjige);
	}

	public ArrayList<String> getDostupneKnjige() {
		return dostupneKnjige;
	}

	public void prikaziDostupneKnjige() {
		System.out.println("Dostupne knjige u biblioteci " + this.ime + ":");
		for (String knjiga : dostupneKnjige) {
			System.out.println(knjiga);
		}
	}

	public void ukloniKnjigu(String knjiga) {
		dostupneKnjige.remove(knjiga);
	}

	public void dodajKnjigu(String knjiga) {
		dostupneKnjige.add(knjiga);
	}

	public int getId() {
		return id;
	}
}
