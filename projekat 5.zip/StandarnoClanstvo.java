package posleKolkvijuma;

public class StandarnoClanstvo extends Clan {
	private static final int MAKS_POZAJMLJENIH_KNJIGA = 5;
	private static final double GODISNJA_NAKNADA = 110;

	public StandarnoClanstvo(String imePrezime, Biblioteka biblioteka) {
		super(imePrezime, biblioteka);
	}

	@Override
	public int getMaksPozajmljenihKnjiga() {
		return MAKS_POZAJMLJENIH_KNJIGA;
	}

	@Override
	public double izracunajGodisnjuNaknadu() {
		return GODISNJA_NAKNADA;
	}
}
