package posleKolkvijuma;

import java.util.ArrayList;
import java.util.Random;

abstract class Clan {
	private String imePrezime;
	private Biblioteka biblioteka;
	private String brojClanstva;
	private ArrayList<String> pozajmljeneKnjige = new ArrayList<>();
	private int brojPozajmljenihKnjiga = 0;

	public abstract int getMaksPozajmljenihKnjiga();

	public abstract double izracunajGodisnjuNaknadu();

	public Clan(String imePrezime, Biblioteka biblioteka) {
		this.imePrezime = imePrezime;
		this.biblioteka = biblioteka;
		this.brojClanstva = generisiBrojClanstva();
	}

	private String generisiBrojClanstva() {
		int idBiblioteke = biblioteka.getId();
		int randomCifre = new Random().nextInt(900000000) + 100000000;
		int kontrolniBroj = new Random().nextInt(90) + 10;
		return idBiblioteke + "-" + randomCifre + "-" + kontrolniBroj;
	}

	public void pozajmiKnjigu(String imeKnjige) {
		if (biblioteka.getDostupneKnjige().contains(imeKnjige)
				&& brojPozajmljenihKnjiga < getMaksPozajmljenihKnjiga()) {
			pozajmljeneKnjige.add(imeKnjige);
			brojPozajmljenihKnjiga++;
			biblioteka.ukloniKnjigu(imeKnjige);
			System.out.println(imePrezime + " je uspješno pozajmio/la knjigu '" + imeKnjige + "'.");
		} else {
			System.out.println("Nije moguće pozajmiti knjigu '" + imeKnjige + "'.");
		}
	}

	public void vratiKnjigu(String imeKnjige) {
		if (pozajmljeneKnjige.contains(imeKnjige)) {
			pozajmljeneKnjige.remove(imeKnjige);
			brojPozajmljenihKnjiga--;
			biblioteka.dodajKnjigu(imeKnjige);
			System.out.println(imePrezime + " je uspješno vratio/la knjigu '" + imeKnjige + "'.");
		} else {
			System.out.println("Knjiga '" + imeKnjige + "' nije pozajmljena.");
		}
	}
}
