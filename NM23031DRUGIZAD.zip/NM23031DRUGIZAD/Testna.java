package posleKolovijuma;

public class Testna {
	public static void main(String[] args) {

		// Kreiramo restoran
		Restoran restoran = new Restoran("Bistro Kod Ane", "Njegoševa 12", "12345678");

		// Kreiramo zaposlene
		Konobar k1 = new Konobar("A1", "Nikolina", "Maras", 10, 40, 5);
		Konobar k2 = new Konobar("A2", "Milica", "Mitrovic", 11, 38, 3);
		Kuvar ku = new Kuvar("A3", "Marija", "Jovanovic", 12, 37);
		Menadzer m1 = new Menadzer("B4", "Anita", "Anic", 15, 35, 500);
		Menadzer m2 = new Menadzer("B5", "Milos", "Milosevicic", 16, 32, 800);

		// Dodajemo zaposlene u restoran
		restoran.dodajZaposlenog(k1);
		restoran.dodajZaposlenog(k2);
		restoran.dodajZaposlenog(ku);
		restoran.dodajZaposlenog(m1);
		restoran.dodajZaposlenog(m2);

		// Generišemo obračun plata
		restoran.generisiObracun("Novembar", 2025);

		// Ukupan trošak
		System.out.println();
		System.out.println("Ukupan trošak plata restorana: " + restoran.izracunajUkupanTrosak() + " €");
	}
}
