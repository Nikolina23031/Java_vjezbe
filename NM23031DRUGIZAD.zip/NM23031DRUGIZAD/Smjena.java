package posleKolovijuma;

import java.util.ArrayList;

public class Smjena {

	private String datum;
	private String pocetak;
	private String kraj;
	private String tipSmjene;
	private ArrayList<Zaposleni> zaposleniUSmjeni;

	public Smjena(String datum, String pocetak, String kraj, String tipSmjene) {
		this.datum = datum;
		this.pocetak = pocetak;
		this.kraj = kraj;
		this.tipSmjene = tipSmjene;
		this.zaposleniUSmjeni = new ArrayList<>();
	}

	public String getTipSmjene() {
		return tipSmjene;
	}

	public void setTipSmjene(String tipSmjene) {

		if (tipSmjene.equalsIgnoreCase("jutarnja") || tipSmjene.equalsIgnoreCase("popodnevna")
				|| tipSmjene.equalsIgnoreCase("nocna")) {
			this.tipSmjene = tipSmjene;
		} else {
			throw new IllegalArgumentException("Jutarnja,nocna ili popodnevna msjean nema 4.");
		}
	}

	public void dodajZaposlenog(Zaposleni z) {
		zaposleniUSmjeni.add(z);
	}

	public ArrayList<Zaposleni> getZaposleniUSmjeni() {
		return zaposleniUSmjeni;
	}

	public double trajanjeUSatima() {

		int satPocetak = Integer.parseInt(pocetak.split(":")[0]);
		int satKraj = Integer.parseInt(kraj.split(":")[0]);
		return satKraj - satPocetak;
	}

	@Override
	public String toString() {
		return datum + " (" + tipSmjene + ") [" + pocetak + " - " + kraj + "]";
	}
}
