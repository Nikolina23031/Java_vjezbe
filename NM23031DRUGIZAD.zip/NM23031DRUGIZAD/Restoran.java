package posleKolovijuma;

import java.util.ArrayList;

public class Restoran {
	private String naziv;
	private String adresa;
	private String pib;
	private ArrayList<Zaposleni> zaposleni;
	private ArrayList<Smjena> smjene;
	private ArrayList<ObracunPlate> istorija;

	public Restoran(String naziv, String adresa, String pib) {
		this.naziv = naziv;
		this.adresa = adresa;
		this.pib = pib;
		this.zaposleni = new ArrayList<>();
		this.smjene = new ArrayList<>();
		this.istorija = new ArrayList<>();
	}

	public void dodajZaposlenog(Zaposleni z) {
		zaposleni.add(z);
	}

	public void dodajSmjenu(Smjena s) {
		smjene.add(s);
	}

	public void generisiObracun(String mjesec, int godina) {
		System.out.println("Obračun plata za " + mjesec + " " + godina);
		System.out.println("--------------------------------");

		for (Zaposleni z : zaposleni) {
			double plata = z.izracunajPlatu();
			String napomena = "";

			if (z instanceof Konobar)
				napomena = "uracunat prekovremeni rad";
			else if (z instanceof Menadzer)
				napomena = "uracunat bonus";
			else if (z instanceof Kuvar)
				napomena = "ukljucen dodatak 1500 €";

			ObracunPlate o = new ObracunPlate(mjesec, godina, z, plata, napomena);
			istorija.add(o);
			System.out.println(o);
		}
	}

	public void prikaziIstoriju() {
		System.out.println("Istorija obracuna plata:");
		for (ObracunPlate o : istorija)
			System.out.println(o);
	}

	public String izracunajUkupanTrosak() {
		return null;
	}
}
